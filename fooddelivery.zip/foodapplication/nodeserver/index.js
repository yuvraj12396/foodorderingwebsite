const io = require('socket.io')(8000)
io.on('connection', function(socket){
	socket.on('send',function(name,order,address,mobileno){
		console.log('order placed')
		socket.broadcast.emit('receive',{name: name,order: order,address: address,mobileno:mobileno});
	});
})