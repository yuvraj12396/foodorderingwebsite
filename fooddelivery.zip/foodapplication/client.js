const socket = io('http://localhost:8000');
const form = document.getElementById('or')
const nm = document.getElementById('username');
const odr = document.getElementById('orddesc');
const add = document.getElementById('addr');
const no = document.getElementById('cntno')
const messageContainer = document.querySelector(".container1")
const append = (message,position)=>{
	const messageElement = document.createElement('div');
	messageElement.innerText = message;
	messageElement.classList.add('message');
	messageElement.classList.add(position);
	messageContainer.append(messageElement);
}

form.addEventListener('submit',(e)=>{
	e.preventDefault();
	const name = nm.value;
	const order = odr.value;
	const address = add.value;
	const mobileno = no.value;
	socket.emit('send',name,order,address,mobileno);
	nm.value ='';
	odr.value ='';
	add.value ='';
	no.value ='';
})



socket.on('receive',data => {
	append(`${data.name}: ${data.address} :${data.order}:${data.mobileno}`,'left')
})
