const socket = io('http://localhost:8000');
const form = document.getElementById('or')
const nm = document.getElementById('username');
const odr = document.getElementById('orddesc');
const add = document.getElementById('addr');
const no = document.getElementById('cntno')
const messageContainer = document.querySelector(".container1")
const append = (message,position)=>{
	const messageElement = document.createElement('div');
	messageElement.innerText = message;
	messageElement.classList.add('message');
	messageElement.classList.add(position);
	messageContainer.append(messageElement);
}





socket.on('receive',data => {
	append(`name : ${data.name} ,address : ${data.address} , order : ${data.order} , mobileno : ${data.mobileno}`,'left')
})